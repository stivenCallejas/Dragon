package modelo;

public class Nodo {
    char dato;
    Nodo siguiente;

    public Nodo(char dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}
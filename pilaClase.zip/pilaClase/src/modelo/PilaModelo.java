/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author 57312
 */
import java.util.Stack;

public class PilaModelo {
    private Stack<Integer> pila;

    public PilaModelo() {
        pila = new Stack<>();
    }

    // Método para apilar (Push)
    public void apilar(int dato) {
        if (pila.isEmpty() || dato == pila.peek() + 1) {
            pila.push(dato);
        } else {
            System.out.println("El dato no cumple con la condición");
        }
    }

    // Método para desapilar (Pop)
    public void desapilar() {
        if (!pila.isEmpty()) {
            pila.pop();
        } else {
            System.out.println("La pila está vacía");
        }
    }

    // Método para mostrar la pila
    public void mostrarPila() {
        if (pila.isEmpty()) {
            System.out.println("La pila está vacía");
        } else {
            System.out.println("Contenido de la pila: " + pila);
        }
    }
}

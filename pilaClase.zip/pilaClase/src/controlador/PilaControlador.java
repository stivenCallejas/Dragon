/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.PilaModelo;
import vista.newpackage.PilaVista;

/**
 *
 * @author 57312
 */
public class PilaControlador {

    private PilaModelo modelo;
    private PilaVista vista;

    public PilaControlador(PilaModelo modelo, PilaVista vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void iniciar() {
        int opcion = 0;
        while (opcion != 4) {
            vista.mostrarMenu();
            opcion = vista.leerNumero();
            switch (opcion) {
                case 1:
                    int numero = vista.leerNumero();
                    modelo.apilar(numero);
                    break;
                case 2:
                    modelo.desapilar();
                    break;
                case 3:
                    modelo.mostrarPila();
                    break;
                case 4:
                    vista.mostrarMensaje("Saliendo...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
                    break;
            }
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pilaclase;

import controlador.PilaControlador;
import modelo.PilaModelo;
import vista.newpackage.PilaVista;

/**
 *
 * @author 57312
 */
public class PilaClase {

    /**
     * @param args the command line arguments
     */

  public static void main(String[] args) {
        PilaModelo modelo = new PilaModelo();
        PilaVista vista = new PilaVista();
        PilaControlador controlador = new PilaControlador(modelo, vista);
        controlador.iniciar();
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista.newpackage;

/**
 *
 * @author 57312
 */
import java.util.Scanner;

public class PilaVista {

    private Scanner scanner;

    public PilaVista() {
        scanner = new Scanner(System.in);
    }

    // Método para mostrar opciones al usuario
    public void mostrarMenu() {
        System.out.println("1. Apilar un número");
        System.out.println("2. Desapilar un número");
        System.out.println("3. Mostrar la pila");
        System.out.println("4. Salir");
    }

    // Método para leer un número del usuario
    public int leerNumero() {
        System.out.print("Ingrese un número: ");
        return scanner.nextInt();
    }

    // Método para mostrar un mensaje al usuario
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
